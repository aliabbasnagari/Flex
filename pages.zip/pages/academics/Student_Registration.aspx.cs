﻿using Flex.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Flex.pages.academics
{
    public partial class Student_Registration : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection("Data Source=anonymous\\SQLEXPRESS;Initial Catalog=FlexDB;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                loadCampusOptions();
            }

        }

        protected void loadCampusOptions()
        {
            conn.Open();
            string query = "select CampusID, CampusName from Campus;";
            SqlCommand command = new SqlCommand(query, conn);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    string cname = reader["CampusName"].ToString();
                    string cid = reader["CampusID"].ToString();
                    ddCampus.Items.Add(new ListItem(cname, cid));
                }
            }
            reader.Close();
            conn.Close();
        }

        protected void loadDegreeOptions()
        {
            conn.Open();
            ddDegree.Items.Clear();
            string query = "select d.DegreeCode, d.DegreeID from CampusDegree cd join Degree d on d.DegreeID = cd.DegreeID where cd.CampusID = @cid";
            SqlCommand command = new SqlCommand(query, conn);
            command.Parameters.AddWithValue("@cid", ddCampus.SelectedValue);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    string dcode = reader["DegreeCode"].ToString();
                    string did = reader["DegreeID"].ToString();
                    ddDegree.Items.Add(new ListItem(dcode, did));
                }
            }
            reader.Close();
            conn.Close();
        }

        protected void loadSectionOptions()
        {
            conn.Open();
            ddSections.Items.Clear();
            string query = "select SectionID, SectionName from Sections s where s.AvailableSeats != 0 and s.DegreeId = @did;";
            SqlCommand command = new SqlCommand(query, conn);
            command.Parameters.AddWithValue("@did", ddDegree.SelectedValue);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    string sname = reader["SectionName"].ToString();
                    string sid = reader["SectionID"].ToString();
                    ddSections.Items.Add(new ListItem(sname, sid));
                }
            }
            reader.Close();
            conn.Close();
        }

        protected void btnGenerate_Click(object sender, EventArgs e)
        {
            conn.Open();
            int start = 1000;
            string query = "select count(*) + 1 as 'NewRoll' from Students;";
            SqlCommand command = new SqlCommand(query, conn);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.HasRows)
            {
                if (reader.Read())
                {
                    string new_roll = reader["NewRoll"].ToString();
                    start += int.Parse(new_roll);
                    string yy = DateTime.Now.ToString("yy");
                    string roll_gen = yy + ddCampus.SelectedItem.Text[0] + "-" + start.ToString();
                    string nuemail_gen = char.ToLowerInvariant(ddCampus.SelectedItem.Text[0]) + yy + start.ToString() + "@nu.edu.pk";
                    rollNo.Text = roll_gen;
                    nuEmail.Text = nuemail_gen;
                }
            }
            reader.Close();
            conn.Close();
        }

        protected void ddDegree_Selected(object sender, EventArgs e)
        {
            loadSectionOptions();
        }

        protected void ddCampus_Selected(object sender, EventArgs e)
        {
            loadDegreeOptions();
        }
    }
}